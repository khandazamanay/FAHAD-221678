/*
 * GccApplication1.c
 *
 * Created: 1/10/2024 6:12:12 PM
 * Author : waris
 */ 

#include <avr/io.h>


int main(void)
{
    
}

